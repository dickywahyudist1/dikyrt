#!/system/xbin/bash
#!/system/xbin/botbrew
apt-get update && upgrade
apt-get install python2
apt-get install toilet
apt-get install php
apt-get install figlet
pip2 install requests
pip2 install mechanize
pkg install ruby
gem install lolcat
